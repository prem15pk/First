package mypackage;

import java.util.Arrays;

public class Test05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] array1 = {5,2,7,9,6};
		
		System.out.println("The original array: "+Arrays.toString(array1));
		for(int i=4;i<0;i--) {
			int temp = array1[i];
			System.out.println(temp);
		}
	}

}
