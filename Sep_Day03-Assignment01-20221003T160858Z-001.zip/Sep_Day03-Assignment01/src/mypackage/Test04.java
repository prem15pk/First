package mypackage;

public class Test04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] array1 = {5,2,7,7,5};
		
		for(int i=0;i<4;i++) {
			for(int j=i+1;j<5;j++) {
				if(array1[i]==array1[j] && i!=j){
					System.out.println("The duplicate elements are: "+array1[i]);
				}
			}
		}
	}

}
