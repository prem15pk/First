package mypackage;

public class Test12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] array1 = {50,77,12,54,-11};
		
		for(int numbers:array1) {
			if(numbers == 0 || numbers == -1) {
				System.out.println("False");
			}
		}
		System.out.println("True");
	}

}
